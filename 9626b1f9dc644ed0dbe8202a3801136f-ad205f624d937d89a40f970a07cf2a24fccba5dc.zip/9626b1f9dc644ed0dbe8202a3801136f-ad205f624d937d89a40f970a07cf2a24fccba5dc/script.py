import numpy as np
import pandas as pd
from scipy.stats import pearsonr, chi2_contingency
import matplotlib.pyplot as plt
import seaborn as sns

import codecademylib3
np.set_printoptions(suppress=True, precision = 2)

nba = pd.read_csv('./nba_games.csv')

# Subset Data to 2010 Season, 2014 Season
nba_2010 = nba[nba.year_id == 2010]
nba_2014 = nba[nba.year_id == 2014]

print(nba_2010.head())
# print(nba_2014.head())

# averages 2010
knicks_pts_10 = nba_2010[nba_2010.fran_id == 'Knicks']
nets_pts_10 = nba_2010[nba_2010.fran_id == 'Nets']
knicks_pts_avg = knicks_pts_10.pts.mean()
nets_pts_avg = nets_pts_10.pts.mean() 
diff_means_2010 = knicks_pts_10.pts.mean() - nets_pts_10.pts.mean() 
#averages 2014
knicks_pts_14 = nba_2014[nba_2014.fran_id == 'Knicks']
nets_pts_14 = nba_2014[nba_2014.fran_id == 'Nets']
knicks_pts_avg14 = knicks_pts_14.pts.mean()
nets_pts_avg14 = nets_pts_14.pts.mean() 
diff_means_2014 = knicks_pts_14.pts.mean() - nets_pts_14.pts.mean() 
#histograms, 2010
plt.hist(knicks_pts_10.pts, alpha=0.8, label='Knicks')
plt.hist(nets_pts_10.pts, alpha=0.8, label='Nets')
plt.legend()
plt.title('2010 season')
plt.xlabel('Points')
plt.ylabel('Frequency')
plt.show()
plt.close()
#2014
plt.hist(knicks_pts_14.pts, normed = True, alpha=0.8, label='knicks')
plt.hist(nets_pts_14.pts, normed = True, alpha=0.8, label='nets')
plt.legend()
plt.title('2014 season' )
plt.show()
plt.close
# points scored divided by teams
plt.figure(figsize= (10,6))
sns.boxplot(x=nba_2010.fran_id, y=nba_2010.pts, )
plt.xlabel('teams')
plt.ylabel('points')
plt.title('points scored by teams')
plt.show()
plt.close()
#do they win more at home or away?
location_result_freq = pd.crosstab(nba_2010.game_result, nba_2010.game_location)
location_result_prop = pd.crosstab(nba_2010.game_result, nba_2010.game_location, normalize=True)
print(location_result_freq)
print(location_result_prop)

chi2, pval, dof, expected = chi2_contingency(location_result_freq)
print(expected)
print(chi2,pval)
#Forecast VS Results
print(np.cov(nba_2010.forecast, nba_2010.point_diff))
point_diff_forecast_corr, p = pearsonr(nba_2010.forecast, nba_2010.point_diff)
print(point_diff_forecast_corr, p)

plt.figure(figsize= (8,6))
plt.scatter(nba_2010.forecast, nba_2010.point_diff,)
plt.legend()
plt.xlabel('forecast')
plt.ylabel("point difference")
plt.title('2010 forecast VS results')
plt.show()
plt.close()